package com.example.yangchaoming.bappdemo.demo1

interface OnKeyBoardStateListener {
     fun onSoftKeyBoardState(visible: Boolean, keyboardHeight: Int, displayHeight: Int)
}