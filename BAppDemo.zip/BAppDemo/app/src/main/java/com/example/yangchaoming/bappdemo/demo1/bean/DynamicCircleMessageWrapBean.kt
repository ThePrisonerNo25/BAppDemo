package com.example.yangchaoming.bappdemo.demo1.bean

data class DynamicCircleMessageWrapBean (var dataList:ArrayList<DynamicCircleMessageBean>?)