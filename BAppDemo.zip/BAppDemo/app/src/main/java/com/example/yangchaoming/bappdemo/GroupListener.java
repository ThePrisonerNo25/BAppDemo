package com.example.yangchaoming.bappdemo;

public interface GroupListener {
    String getGroupName(int position);
}
