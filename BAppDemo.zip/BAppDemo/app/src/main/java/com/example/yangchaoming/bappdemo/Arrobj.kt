package com.example.yangchaoming.bappdemo

data class Arrobj (var name:String, var age:Int)