package com.example.yangchaoming.bappdemo.step_test

import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.yangchaoming.bappdemo.R
import com.example.yangchaoming.bappdemo.step_test.view.ButtonStartView

class Step1TestActivity : AppCompatActivity() {
    val tag = "Step1TestActivity";
    private lateinit var btnStart: ButtonStartView
    private lateinit var btnRestart: Button
    private lateinit var btnSkip: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_step1_test)
        initView()
    }

    private fun initView() {
        btnStart = findViewById(R.id.btn_start)
        btnRestart = findViewById(R.id.btn_restart)
        btnSkip = findViewById(R.id.btn_skip)

        btnStart.setOnClickListener { v ->
            run {
                if (btnStart.isStart) {
                    Log.e(tag, "initView: isStart");
                    btnStart.setState(!btnStart.isPause)
                } else {
                    btnStart.setState(!btnStart.isPause)
                }

            }
        }

        btnRestart.setOnClickListener { v -> btnStart.setRestart() }

        btnStart.mStateChangeListener = object : ButtonStartView.StateChangeListener {
            override fun restart() {

            }

            override fun stateChanged(isPause: Boolean) {
                Log.e(tag, "stateChanged: ispause  = $isPause");
            }

        }

    }
}