package com.example.yangchaoming.bappdemo.observe;

public class Product {
}
